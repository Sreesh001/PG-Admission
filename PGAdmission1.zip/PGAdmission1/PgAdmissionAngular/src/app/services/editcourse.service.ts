import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddcourseComponent, CourseModel } from '../admin/addcourse/addcourse.component';

const URL: any = 'https://localhost:44398/api/Admin/editCourse?id';

@Injectable({
  providedIn: 'root',
})
export class editcourseService {
  private URL = 'https://localhost:44398/api';

  constructor(private http: HttpClient) { }

  public updateCourse(id: string, course: any) {
    return this.http.put(this.URL + '/admin/editCourse/' + id, course, {
      responseType: 'text' as 'json',
    });

  }
}


