﻿using System.ComponentModel.DataAnnotations;

namespace PgAdmission.Models
{
    public class LoginModel
    {
        [Key]
        [Required(ErrorMessage = "Email is Required")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Password is Required")]
        public string Password { get; set; }
    }
}
