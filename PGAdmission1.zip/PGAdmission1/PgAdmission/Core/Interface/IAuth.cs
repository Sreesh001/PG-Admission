﻿using PgAdmission.Models;
using System.Threading.Tasks;

namespace PgAdmission.Core.Interface
{
        public interface IAuth
        {
            Task<ResponseModel> RegisterUser(UserModel userModel);
            ResponseModel GenerateToken(LoginModel loginModel);

        }

    }

